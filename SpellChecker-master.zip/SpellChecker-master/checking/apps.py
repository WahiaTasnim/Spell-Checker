from django.apps import AppConfig


class CheckingConfig(AppConfig):
    name = 'checking'
